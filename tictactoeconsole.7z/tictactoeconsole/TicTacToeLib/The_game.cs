﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace TicTacToeLib
{
    public class The_Game
    {
        public static void wp(string[] b, string[] g, int lg, int ff, string xo, string tryb, int win, int a1)
        {
            The_Game pr = new The_Game();
            for (int i = 1; i < 10; i++)
            {
                if (i == a1)
                {
                    if (b[i] == "_")
                    {
                        if (xo == "o" || xo == "O")
                        {
                            b[i] = "O";
                            xo = "X";
                        }
                        else
                        {
                            b[i] = "X";
                            xo = "O";
                        }
                        if (lg == 0)
                        {
                            lg++;
                        }
                        else lg--;
                        ff++;
                    }
                    else
                    {
                        Console.WriteLine("Error:field occupied by the player. Looking for another. ");
                        Thread.Sleep(2000);
                        break;
                    }
                }
            }
            if (ff >= 3)
               Function.spr(b, g, lg, ff, xo, tryb, win);
            else Board.Boa(b, g, lg, ff, xo, tryb, win);
        }
    }
}
