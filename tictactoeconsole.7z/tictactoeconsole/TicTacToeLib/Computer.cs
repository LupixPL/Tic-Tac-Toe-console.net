﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;


namespace TicTacToeLib
{
    public class Computer
    {
        public static void com(string[] b, string[] g, int lg, int ff, string xo, string tryb, int win) //computer walking function
        {
            Computer pr = new Computer();
            int a1 = 0;
            Random rnd = new Random();
            int ck = rnd.Next(1, 9);
            Console.WriteLine("computer movement: ");
            Thread.Sleep(1000);
            Console.WriteLine(ck);
            Thread.Sleep(500);
            a1 = ck;
            The_Game.wp(b, g, lg, ff, xo, tryb, win, a1);
           
        }
    }
}
