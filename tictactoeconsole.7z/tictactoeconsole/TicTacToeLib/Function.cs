﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace TicTacToeLib
{
    public class Function
    {
        public static void spr(string[] b, string[] g, int lg, int ff, string xo, string tryb, int win) //  Function for checking winnings
        {
            
            int f1 = 1, f2 = 2, f3 = 3, gracw = 0; string[] c = { "X", "O" };
            for (int s = 0; s < 2; s++)
            {
                for (int i = 0; i < 3; i++)
                {
                    if (b[f1] == c[gracw] && b[f2] == c[gracw] && b[f3] == c[gracw])
                    {
                        b[f1] = "."; b[f2] = "."; b[f3] = ".";
                        Console.WriteLine("The player has won: " + g[gracw]);
                        Thread.Sleep(2000);
                        win = 1;
                        Function.spr(b, g, lg, ff, xo, tryb, win);
                    }
                    f1 += 3; f2 += 3; f3 += 3;
                }
                f1 = 1; f2 = 2; f3 = 3;
                gracw = 1;
            }
            f1 = 1; f2 = 4; ; f3 = 7; gracw = 0;
            for (int s = 0; s < 2; s++)
            {
                for (int i = 0; i < 3; i++)
                {
                    if (b[f1] == c[gracw] && b[f2] == c[gracw] && b[f3] == c[gracw])
                    {
                        b[f1] = "."; b[f2] = "."; b[f3] = ".";
                        Console.WriteLine("The player has won: " + g[gracw]);
                        Thread.Sleep(2000);
                        win = 1;
                        Function.spr(b, g, lg, ff, xo, tryb, win);
                    }
                    f1 += 1; f2 += 1; f3 += 1;
                }
                f1 = 1; f2 = 4; f3 = 7;
                gracw = 1;
            }
            f1 = 1; f2 = 5; ; f3 = 9; gracw = 0;
            for (int s = 0; s < 2; s++)
            {
                for (int i = 0; i < 2; i++)
                {
                    if (b[f1] == c[gracw] && b[f2] == c[gracw] && b[f3] == c[gracw])
                    {
                        b[f1] = "."; b[f2] = "."; b[f3] = ".";
                        Console.WriteLine("The player has won: " + g[gracw]);
                        Thread.Sleep(2000);
                        win = 1;
                        Function.spr(b, g, lg, ff, xo, tryb, win);
                    }
                    f1 = 3; f2 = 5; f3 = 7;
                }
                f1 = 1; f2 = 4; f3 = 9;
                gracw = 1;
            }
            Board.Boa(b, g, lg, ff, xo, tryb, win);
        }

    }
}
