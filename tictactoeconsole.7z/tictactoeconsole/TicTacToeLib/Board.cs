﻿using System;
using System.Threading;

namespace TicTacToeLib
{
    public class Board
    {
        public enum Player
        {
            player
        }
        public static void Boa(string[] b, string[] g, int lg, int ff, string xo, string tryb, int win)

        {
            Board pr = new Board();
            int a1 = 0;
        String place;
        Console.Clear();
                Console.Write("you start " + g[lg] + " ");
                Console.Write(Player.player);
                Console.WriteLine();
                Console.WriteLine("-------[" + b[1] + "]-------[" + b[2] + "]-------[" + b[3] + "]-------");
                Console.WriteLine("-------------------------------------");
                Console.WriteLine("-------[" + b[4] + "]-------[" + b[5] + "]-------[" + b[6] + "]-------");
                Console.WriteLine("-------------------------------------");
                Console.WriteLine("-------[" + b[7] + "]-------[" + b[8] + "]-------[" + b[9] + "]-------");
                if (win == 1) { Thread.Sleep(2000); System.Environment.Exit(1); }
    Console.WriteLine("enter a place from 1 to 9: ");
                Console.WriteLine("move of player " + xo);
                if (tryb == "1" && xo == "O")
                {
                   Computer.com(b, g, lg, ff, xo, tryb, win);
                }
                else
                {
                    place = Console.ReadLine();
                    a1 = Int32.Parse(place);
                    The_Game.wp(b, g, lg, ff, xo, tryb, win, a1);
                }
            }
    }
}

