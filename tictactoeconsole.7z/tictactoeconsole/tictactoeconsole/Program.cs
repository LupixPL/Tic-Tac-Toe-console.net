﻿using System;
using System.ComponentModel;
using System.Threading;
using TicTacToeLib;

namespace tictactoeconsole
{

    public class Program
    {
        public static void Main() //game mode selection
        {
            int lg = 0;
            string xo = "X";
            int win = 0;
            int ff = 0;
            Program pr = new Program();
            string[] grace = { "first", "second" };
            string[] b = { "_", "_", "_", "_", "_", "_", "_", "_", "_", "_", };
            Console.WriteLine("Tic-tac-toe game ");
            Console.WriteLine("1 - Single player game");
            Console.WriteLine("2 - Two player game");
            Console.WriteLine("select game mode: ");
            String tryb = Console.ReadLine();
            if (tryb == "2")
            {
                Console.WriteLine("You have chosen the two player game mode ");
                Thread.Sleep(2000);
                Console.Clear();
                Board.Boa(b, grace, lg, ff, xo, tryb, win);
            }
            else if (tryb == "1")
            {
                Console.WriteLine("You have chosen the single player game ");
                Thread.Sleep(2000);
                grace[1] = "computer";
                Console.Clear();
                Board.Boa(b, grace, lg, ff, xo, tryb, win);
            }
            Console.ReadKey();
        }
    }
}


                